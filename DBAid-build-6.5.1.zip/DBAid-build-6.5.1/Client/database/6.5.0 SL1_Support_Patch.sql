/*
Copyright (C) 2024 Datacom
GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007
*/
/*
WHEN RUNNING THIS SCRIPT IN SSMS, SQLCMD MODE MUST BE ENABLED. 

It is assumed you already have DBAid v6.5.0 deployed, or at least the [_dbaid] database therein.
This script is intended to be used on SQL Server 2012 or later. 
  It has been tested with SQL Server 2008 R2 + DBAid 6.3.0 and seems to work OK but no guarantees. 
  It has not been tested with earlier, unsupported versions of SQL Server.
This script will create the objects required to be able to generate alerts in SL1 for backups, integrity checks, job failures, and long-running jobs.
Monitoring logic is done in this code. Alerts are written to the Windows Application Event Log. 
SL1 has a scraper to detect these alerts and raise Events.
The required SQL Agent jobs are created DISABLED by default. You will need to enable them. Ensure the [_dbaid_SL1_inventory] job is run first.
*/
SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, CONCAT_NULL_YIELDS_NULL, QUOTED_IDENTIFIER ON;

SET NUMERIC_ROUNDABORT OFF;
GO

:setvar Version "6.5.1 patch"
:setvar DatabaseName "_dbaid"

/*
Detect SQLCMD mode and disable script execution if SQLCMD mode is not supported.
To re-enable the script after enabling SQLCMD mode, execute the following:
SET NOEXEC OFF; 
*/
:setvar __IsSqlCmdEnabled "True"
GO
IF N'$(__IsSqlCmdEnabled)' NOT LIKE N'True'
    BEGIN
        PRINT N'SQLCMD mode must be enabled to successfully execute this script.';
        SET NOEXEC ON;
    END
GO

USE [_dbaid];
GO
IF EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'config_database_SL1' AND [schema_id] = SCHEMA_ID(N'dbo') AND [type] = 'U')
	DROP TABLE [dbo].[config_database_SL1];
GO
CREATE TABLE [dbo].[config_database_SL1]
(
	[name] sysname NOT NULL CONSTRAINT PK_config_database_SL1 PRIMARY KEY CLUSTERED,

	[database_check_alert] VARCHAR(10) NOT NULL CONSTRAINT DF_config_database_SL1_database_check_alert DEFAULT 'CRITICAL',
	[database_check_enabled] BIT NOT NULL CONSTRAINT DF_config_database_SL1_database_check_enabled DEFAULT 0,

	[backup_check_alert] VARCHAR(10) NOT NULL CONSTRAINT DF_config_database_SL1_backup_check_alert DEFAULT 'WARNING',
	[backup_check_enabled] BIT NOT NULL CONSTRAINT DF_config_database_SL1_backup_check_enabled DEFAULT 1,
	[backup_check_full_hour] INT NULL CONSTRAINT DF_config_database_SL1_backup_check_full_hour DEFAULT 30,
	[backup_check_diff_hour] INT NULL CONSTRAINT DF_config_database_SL1_backup_check_diff_hour DEFAULT 30,
	[backup_check_tran_hour] INT NULL CONSTRAINT DF_config_database_SL1_backup_check_tran_hour DEFAULT 1,

	[integrity_check_alert] VARCHAR(10) NOT NULL CONSTRAINT DF_config_database_SL1_integrity_check_alert DEFAULT 'WARNING',
	[integrity_check_hour] INT NOT NULL CONSTRAINT DF_config_database_SL1_integrity_check_hour DEFAULT 170, 
	[integrity_check_enabled] BIT NOT NULL CONSTRAINT DF_config_database_SL1_integrity_check_enabled DEFAULT 1,

	[logshipping_check_alert] VARCHAR(10) NOT NULL CONSTRAINT DF_config_database_SL1_logshipping_check_alert DEFAULT 'WARNING',
	[logshipping_check_hour] INT NOT NULL CONSTRAINT DF_config_database_SL1_logshipping_check_hour DEFAULT 2, 
	[logshipping_check_enabled] BIT NOT NULL CONSTRAINT DF_config_database_SL1_logshipping_check_enabled DEFAULT 0,

	[mirroring_check_alert] VARCHAR(10) NOT NULL CONSTRAINT DF_config_database_SL1_mirroring_check_alert DEFAULT 'WARNING',
	[mirroring_check_role] VARCHAR(10) NULL CONSTRAINT DF_config_database_SL1_mirroring_check_role DEFAULT NULL,
	[mirroring_check_enabled] BIT NOT NULL CONSTRAINT DF_config_database_SL1_mirroring_check_enabled DEFAULT 0,

	[capacity_check_warning_free] NUMERIC(5,2) NOT NULL CONSTRAINT DF_config_database_SL1_capacity_check_warning_free DEFAULT 20.00,
	[capacity_check_critical_free] NUMERIC(5,2) NOT NULL CONSTRAINT DF_config_database_SL1_capacity_check_critical_free DEFAULT 10.00, 
	[capacity_check_enabled] BIT NOT NULL CONSTRAINT DF_config_database_SL1_capacity_check_enabled DEFAULT 0,

	[inventory_date] DATETIME CONSTRAINT DF_config_database_inventory_date DEFAULT GETDATE() NOT NULL,

	CONSTRAINT [CK_config_database_SL1] 
	CHECK ([database_check_alert] IN ('OK','WARNING','CRITICAL') 
		AND [backup_check_alert] IN ('OK','WARNING','CRITICAL')
		AND [integrity_check_alert] IN ('OK','WARNING','CRITICAL')
		AND [logshipping_check_alert] IN ('OK','WARNING','CRITICAL')
		AND [mirroring_check_alert] IN ('OK','WARNING','CRITICAL')
		AND [mirroring_check_role] IN (NULL,'PRIMARY','SECONDARY')
		AND [capacity_check_critical_free] <= [capacity_check_warning_free])
);
GO




USE [_dbaid];
GO
IF EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'config_db_alerts_fired_SL1' AND [schema_id] = SCHEMA_ID(N'dbo') AND [type] = 'U')
	DROP TABLE [dbo].[config_db_alerts_fired_SL1];
GO
CREATE TABLE [dbo].[config_db_alerts_fired_SL1]
( 
	[name] sysname NOT NULL CONSTRAINT PK_config_db_alerts_fired_SL1 PRIMARY KEY CLUSTERED,
	[database_check_alert_fired] bit NOT NULL CONSTRAINT DF_config_db_alerts_fired_SL1_database_check_alert_fired DEFAULT 0,
	[backup_alert_fired] bit NOT NULL CONSTRAINT DF_config_db_alerts_fired_SL1_backup_alert_fired DEFAULT 0,
	[integrity_check_alert_fired] bit NOT NULL CONSTRAINT DF_config_db_alerts_fired_SL1_integrity_check_alert_fired DEFAULT 0,
	[logshipping_check_alert_fired] bit NOT NULL CONSTRAINT DF_config_db_alerts_fired_SL1_logshipping_check_alert_fired DEFAULT 0,
	[mirroring_check_alert_fired] bit NOT NULL CONSTRAINT DF_config_db_alerts_fired_SL1_mirroring_check_alert_fired DEFAULT 0,
	[inventory_date] DATETIME CONSTRAINT DF_config_db_alerts_fired_SL1_inventory_date DEFAULT GETDATE() NOT NULL
);
GO




USE [_dbaid];
GO
IF EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'config_agentjob_SL1' AND [schema_id] = SCHEMA_ID(N'dbo') AND [type] = 'U')
	DROP TABLE [dbo].[config_agentjob_SL1];
GO
CREATE TABLE [dbo].[config_agentjob_SL1]
(
	[name] sysname NOT NULL CONSTRAINT PK_config_agentjob_SL1 PRIMARY KEY CLUSTERED,

	[state_check_alert] VARCHAR(10) NOT NULL CONSTRAINT DF_agent_job_SL1_state_check_alert DEFAULT 'WARNING',
	[state_fail_check_enabled] BIT NOT NULL CONSTRAINT DF_agent_job_SL1_state_fail_check_enabled DEFAULT 1,
	[state_cancel_check_enabled] BIT NOT NULL CONSTRAINT DF_agent_job_SL1_state_cancel_check_enabled DEFAULT 0,

	[runtime_check_alert] VARCHAR(10) NOT NULL CONSTRAINT DF_agent_job_SL1_runtime_check_alert DEFAULT 'WARNING',
	[runtime_check_min] INT NOT NULL CONSTRAINT DF_agent_job_SL1_runtime_check_min DEFAULT 200, 
	[runtime_check_enabled] BIT NOT NULL CONSTRAINT DF_agent_job_SL1_runtime_check_enabled DEFAULT 1,
	
	[is_continuous_running_job] BIT NOT NULL CONSTRAINT DF_agent_job_SL1_is_continuous_running_job DEFAULT 0, 
	[inventory_date] DATETIME NOT NULL CONSTRAINT DF_agent_job_SL1_inventory_date DEFAULT GETDATE(), 

	CONSTRAINT [CK_config_agentjob_SL1] 
	CHECK ([state_check_alert] IN ('WARNING','CRITICAL')
		AND [runtime_check_alert] IN ('WARNING','CRITICAL')
		AND [runtime_check_min] > 0)
);
GO




USE [_dbaid];
GO
IF EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'config_agentjob_alerts_fired_SL1' AND [schema_id] = SCHEMA_ID(N'dbo') AND [type] = 'U')
	DROP TABLE [dbo].[config_agentjob_alerts_fired_SL1];
GO
CREATE TABLE [dbo].[config_agentjob_alerts_fired_SL1]
( 
	[name] sysname NOT NULL CONSTRAINT PK_config_agentjob_alerts_fired_SL1 PRIMARY KEY CLUSTERED,
	[job_fail_alert_fired] bit NOT NULL CONSTRAINT DF_config_agentjob_alerts_fired_SL1_job_fail_alert_fired DEFAULT 0,
	[job_long_running_alert_fired] bit NOT NULL CONSTRAINT DF_config_agentjob_alerts_fired_SL1_job_long_running_alert_fired DEFAULT 0,
	[inventory_date] DATETIME CONSTRAINT DF_config_agentjob_alerts_fired_SL1_inventory_date DEFAULT GETDATE() NOT NULL
);
GO



USE [_dbaid];
GO
IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'inventory_database_SL1' AND [schema_id] = SCHEMA_ID(N'check') AND [type] = 'P')
BEGIN
	EXEC sp_executesql N'CREATE PROCEDURE [check].[inventory_database_SL1] AS RETURN 0;';
END
GO
ALTER PROCEDURE [check].[inventory_database_SL1]
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;

	EXECUTE AS LOGIN = '_dbaid_sa';

	/* Inventory config_database_SL1 */
	MERGE INTO [_dbaid].[dbo].[config_database_SL1] [target]
	USING sys.databases [source]
	ON [target].[name] = [source].[name] COLLATE DATABASE_DEFAULT
	WHEN NOT MATCHED BY TARGET THEN
		INSERT ([name]) VALUES ([source].[name])
	WHEN MATCHED THEN
		UPDATE SET [target].[inventory_date] = GETDATE()
	WHEN NOT MATCHED BY SOURCE AND [target].[inventory_date] < DATEADD(DAY, -7, GETDATE()) THEN
		DELETE;

	/* We do not need to monitor tempdb for backups & integrity checks. */
	UPDATE [_dbaid].[dbo].[config_database_SL1]
	SET [backup_check_enabled] = 0, [integrity_check_enabled] = 0, [backup_check_full_hour] = NULL, [backup_check_diff_hour] = NULL, [backup_check_tran_hour] = NULL
	WHERE [name] IN (N'tempdb');

	/* If a setting has been changed from monitored to unmonitored, update the alerts_fired tables to zero out any prior alerts to avoid confusion or future false alerts. */
	UPDATE tgt
	SET [database_check_alert_fired] = 0
	FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] tgt
		INNER JOIN [_dbaid].[dbo].[config_database_SL1] src ON tgt.[name] = src.[name]
	WHERE src.[database_check_enabled] = 0
	  AND tgt.[database_check_alert_fired] = 1;

	UPDATE tgt
	SET [backup_alert_fired] = 0
	FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] tgt
		INNER JOIN [_dbaid].[dbo].[config_database_SL1] src ON tgt.[name] = src.[name]
	WHERE src.[backup_check_enabled] = 0
	  AND tgt.[backup_alert_fired] = 1;

	UPDATE tgt
	SET [integrity_check_alert_fired] = 0
	FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] tgt
		INNER JOIN [_dbaid].[dbo].[config_database_SL1] src ON tgt.[name] = src.[name]
	WHERE src.[integrity_check_enabled] = 0
	  AND tgt.[integrity_check_alert_fired] = 1;

	UPDATE tgt
	SET [logshipping_check_alert_fired] = 0
	FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] tgt
		INNER JOIN [_dbaid].[dbo].[config_database_SL1] src ON tgt.[name] = src.[name]
	WHERE src.[logshipping_check_enabled] = 0
	  AND tgt.[logshipping_check_alert_fired] = 1;

	UPDATE tgt
	SET [mirroring_check_alert_fired] = 0
	FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] tgt
		INNER JOIN [_dbaid].[dbo].[config_database_SL1] src ON tgt.[name] = src.[name]
	WHERE src.[mirroring_check_enabled] = 0 
	  AND tgt.[mirroring_check_alert_fired] = 1;

	/* Inventory config_db_alerts_fired_SL1 */
	MERGE INTO [_dbaid].[dbo].[config_db_alerts_fired_SL1] [target]
	USING sys.databases [source]
	ON [target].[name] = [source].[name] COLLATE DATABASE_DEFAULT
	WHEN NOT MATCHED BY TARGET THEN
		INSERT ([name]) VALUES ([source].[name])
	WHEN MATCHED THEN
		UPDATE SET [target].[inventory_date] = GETDATE()
	WHEN NOT MATCHED BY SOURCE AND [target].[inventory_date] < DATEADD(DAY, -7, GETDATE()) THEN
		DELETE;

	REVERT;
END
GO




USE [_dbaid];
GO
IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'inventory_agentjob_SL1' AND [schema_id] = SCHEMA_ID('check') AND [type] = 'P')
BEGIN
	EXEC sp_executesql N'CREATE PROCEDURE [check].[inventory_agentjob_SL1] AS RETURN 0;';
END
GO
ALTER PROCEDURE [check].[inventory_agentjob_SL1]
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;

	EXECUTE AS LOGIN = '_dbaid_sa';

	/* Inventory config_agentjob_SL1 */
	MERGE INTO [_dbaid].[dbo].[config_agentjob_SL1] AS [target]
	USING (SELECT [J].[name] FROM [msdb].[dbo].[sysjobs] [J]) AS [source]
	ON [target].[name] = [source].[name] COLLATE DATABASE_DEFAULT
	WHEN NOT MATCHED BY TARGET THEN
		INSERT ([name]) VALUES ([source].[name])
	WHEN MATCHED THEN
		UPDATE SET [target].[inventory_date] = GETDATE()
	WHEN NOT MATCHED BY SOURCE THEN
		DELETE;

	/* If a setting has been changed from monitored to unmonitored, update the alerts_fired tables to zero out any prior alerts to avoid confusion or future false alerts. */
	UPDATE tgt
	SET [job_fail_alert_fired] = 0
	FROM [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1] tgt
		INNER JOIN [_dbaid].[dbo].[config_agentjob_SL1] src ON tgt.[name] = src.[name]
	WHERE src.[state_fail_check_enabled] = 0
	  AND tgt.[job_fail_alert_fired] = 1;

	UPDATE tgt
	SET [job_fail_alert_fired] = 0
	FROM [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1] tgt
		INNER JOIN [_dbaid].[dbo].[config_agentjob_SL1] src ON tgt.[name] = src.[name]
	WHERE src.[state_cancel_check_enabled] = 0
	  AND tgt.[job_fail_alert_fired] = 1;

	UPDATE tgt
	SET [job_long_running_alert_fired] = 0
	FROM [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1] tgt
		INNER JOIN [_dbaid].[dbo].[config_agentjob_SL1] src ON tgt.[name] = src.[name]
	WHERE src.[runtime_check_enabled] = 0
	  AND tgt.[job_long_running_alert_fired] = 1;

	/* Inventory config_agentjob_alerts_fired_SL1 */
	MERGE INTO [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1] AS [target]
	USING (SELECT [J].[name] FROM [msdb].[dbo].[sysjobs] [J]) AS [source]
	ON [target].[name] = [source].[name] COLLATE DATABASE_DEFAULT
	WHEN NOT MATCHED BY TARGET THEN
		INSERT ([name]) VALUES ([source].[name])
	WHEN MATCHED THEN
		UPDATE SET [target].[inventory_date] = GETDATE()
	WHEN NOT MATCHED BY SOURCE THEN
		DELETE;

	REVERT;
END
GO




USE [_dbaid];
GO
IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'check_backup_SL1' AND [schema_id] = SCHEMA_ID('check') AND [type] = 'P')
BEGIN
	EXEC sp_executesql N'CREATE PROCEDURE [check].[check_backup_SL1] AS RETURN 0;';
END
GO
ALTER PROCEDURE [check].[check_backup_SL1]
(
	@write_event_log BIT = 1,
	@write_errorlog BIT = 0
)
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;

	EXECUTE AS LOGIN = N'_dbaid_sa';

	DECLARE @backup_enabled INT, @backup_disabled INT, @major_version decimal(3,1);
	DECLARE @preferred_backup TABLE ([name] sysname, [preferred_backup] BIT);
	DECLARE @last_backup TABLE ([name] sysname, [full_backup_date] DATETIME, [diff_backup_date] DATETIME, [tran_backup_date] DATETIME);
	DECLARE @check_output TABLE([state] VARCHAR(8), [message] NVARCHAR(4000), [name] sysname);
	DECLARE @HADR_backup_info TABLE ([timestamp] datetime, [database_name] sysname);

	/* This won't work with anything less than SQL 2012 anyway. Need to allow checking for/running on SQL 2005-2008 (even though not really supported) if only to prevent a nasty exit.
	SELECT @major_version = [major] FROM [system].[get_product_version](); 
	*/
	SELECT @major_version = LEFT(CAST(SERVERPROPERTY('ProductVersion') AS varchar(15)), 2);

	IF @major_version >= 11
	BEGIN
		INSERT INTO @preferred_backup
			EXEC sp_executesql N'SELECT [name], [sys].[fn_hadr_backup_is_preferred_replica]([name]) AS [preferred_backup] FROM [sys].[databases]';
	END

	;WITH [LastBackup]
	AS 
	(
		SELECT ROW_NUMBER() OVER (PARTITION BY [DB].[name], [B].[type] ORDER BY [B].[backup_finish_date] DESC) AS [row]
			,[DB].[name]
			,CASE WHEN [B].[type] = 'D' THEN [B].[backup_finish_date] ELSE NULL END AS [full_backup_date]
			,CASE WHEN [B].[type] = 'I' THEN [B].[backup_finish_date] ELSE NULL END AS [diff_backup_date]
			,CASE WHEN [B].[type] = 'L' THEN [B].[backup_finish_date] ELSE NULL END AS [tran_backup_date]
		FROM [sys].[databases] [DB] 
			LEFT JOIN [msdb].[dbo].[backupset] [B] WITH (NOLOCK)
				ON [DB].[name] = [B].[database_name] COLLATE DATABASE_DEFAULT
			OUTER APPLY(SELECT [preferred_backup] FROM @preferred_backup WHERE [name] = [DB].[name] COLLATE DATABASE_DEFAULT) AS [AG]
		WHERE ([AG].[preferred_backup] = 1 OR [AG].[preferred_backup] IS NULL)
	)
	INSERT INTO @last_backup
		SELECT [name]
			,MAX([full_backup_date])
			,MAX([diff_backup_date])
			,MAX([tran_backup_date])
		FROM [LastBackup] 
		WHERE [row] = 1
		GROUP BY [name];

	/* Look for most recent AG failover. If AG has recently failed over, 
		  it is likely the current preferred replica for backups has also changed and has not had a recent backup run on it.
		We do not want to immediately alert on missed backups in this case, so defer checks by a day (full, diff) and an hour (log)
	*/
	/* Datetimes in the Extended Event session are UTC; not entirely helpful, need to compare against local time. */
	DECLARE @DST_offset smallint;
	SELECT @DST_offset = DATEDIFF(hour, GETUTCDATE(), GETDATE());

	;WITH CTE_HADR AS (
		SELECT object_name, CONVERT(XML, event_data) AS data
		FROM sys.fn_xe_file_target_read_file('AlwaysOn*.xel', null, null, null)
		WHERE [object_name] = 'error_reported'
	),
	CTE_HADR_Filtered AS (
		SELECT DATEADD(hour, @DST_offset, data.value('(/event/@timestamp)[1]','datetime')) AS [timestamp],
			data.value('(/event/data[@name=''message''])[1]','varchar(max)') AS [message]
		FROM CTE_HADR
		WHERE data.value('(/event/data[@name=''error_number''])[1]','int') = 1480
	),
	CTE_HADR_split_message_text AS (
		SELECT [timestamp]
			,[message]
			,CHARINDEX('"', [message], 1) AS [start_db_name_index]
			,CHARINDEX('"', [message], CHARINDEX('"', [message], 1) + 1) AS [end_db_name_index]
			,PATINDEX('%is changing roles from "%', [message]) AS [start_role_change_from_index]
			,CHARINDEX('"', [message], PATINDEX('%is changing roles from "%', [message]) + 24) AS [end_role_change_from_index]
			,PATINDEX('%" to "%', [message]) AS [start_role_change_to_index]
			,CHARINDEX('"', [message], PATINDEX('%" to "%', [message]) + 6) AS [end_role_change_to_index]
		FROM CTE_HADR_Filtered
	),
	CTE_HADR_grouped AS (
		SELECT ROW_NUMBER() OVER (PARTITION BY SUBSTRING([message], [start_db_name_index] + 1, ([end_db_name_index] - [start_db_name_index]) - 1) ORDER BY SUBSTRING([message], [start_db_name_index] + 1, ([end_db_name_index] - [start_db_name_index]) - 1), [timestamp] DESC) AS [rownum]
			,[timestamp]
			,SUBSTRING([message], [start_db_name_index] + 1, ([end_db_name_index] - [start_db_name_index]) - 1) AS [database_name]
			,SUBSTRING([message], [start_role_change_from_index] + 24, [end_role_change_from_index] - ([start_role_change_from_index] + 24)) AS [role_change_from]
			,SUBSTRING([message], [start_role_change_to_index] + 6, [end_role_change_to_index] - ([start_role_change_to_index] + 6)) AS [role_change_to]
		FROM CTE_HADR_split_message_text
	)
	INSERT INTO @HADR_backup_info
		SELECT [timestamp], [database_name]
		FROM CTE_HADR_grouped
		WHERE [rownum] = 1;

	/* For databases that are not in an AG, fudge it; otherwise, check logic has problems. */
	INSERT INTO @HADR_backup_info
		SELECT DATEADD(day, -7, GETDATE()), [name]
		FROM sys.databases
		WHERE [replica_id] IS NULL;

	INSERT INTO @check_output
		SELECT CASE WHEN ([C].[backup_check_full_hour] IS NOT NULL 
									AND [DB].[create_date] < DATEADD(DAY, -1, GETDATE()) /* One day grace period for newly created databases. */
									/* Check for a FULL or DIFF backup within the alert period for the FULL backup. DIFF will suffice if FULL hasn't been done. */
									AND ISNULL([LB].[full_backup_date], 0) < DATEADD(HOUR, -[C].[backup_check_full_hour], GETDATE())
									AND ISNULL([LB].[diff_backup_date], 0) < DATEADD(HOUR, -[C].[backup_check_full_hour], GETDATE())
									AND [CTE].[timestamp] < DATEADD(DAY, -1, GETDATE())) /* One day grace period for AG failover. */
								OR ([C].[backup_check_diff_hour] IS NOT NULL 
									AND [DB].[create_date] < DATEADD(DAY, -1, GETDATE()) /* One day grace period for newly created databases. */
									/* Check for a FULL or DIFF backup within the alert period for the DIFF backup. FULL will cover if DIFF hasn't been done. */
									AND ISNULL([LB].[full_backup_date], 0) < DATEADD(HOUR, -[C].[backup_check_diff_hour], GETDATE()) 
									AND ISNULL([LB].[diff_backup_date], 0) < DATEADD(HOUR, -[C].[backup_check_diff_hour], GETDATE())
									AND [CTE].[timestamp] < DATEADD(DAY, -1, GETDATE())) /* One day grace period for AG failover. */
								OR ([C].[backup_check_tran_hour] IS NOT NULL 
									AND [DB].[create_date] < DATEADD(DAY, -1, GETDATE()) /* One day grace period for newly created databases. */
									AND [DB].[recovery_model] IN (1,2) 
									AND ISNULL([LB].[tran_backup_date], 0) < DATEADD(HOUR, -[C].[backup_check_tran_hour], GETDATE())
									AND [CTE].[timestamp] < DATEADD(HOUR, -1, GETDATE()) /* One hour grace period for AG failover. */
									AND [DB].[name] NOT IN (N'model')) /* These databases may be in FULL recovery model but do not typically have/need log backups. */
								THEN [C].[backup_check_alert]
								ELSE 'OK' END AS [state]
					,QUOTENAME([C].[name]) 
						+ N'; recovery_model=' 
						+ [DB].[recovery_model_desc] COLLATE DATABASE_DEFAULT
						+ CASE 
								WHEN [C].[backup_check_full_hour] IS NOT NULL 
								THEN N'; last_full=' 
									+ CASE
											WHEN [LB].[full_backup_date] IS NULL 
											THEN N'NEVER' 
											ELSE CONVERT(VARCHAR(20), [LB].[full_backup_date], 120) END
							ELSE '' END
						+ CASE 
								WHEN [C].[backup_check_diff_hour] IS NOT NULL 
								THEN N'; last_diff=' 
									+ CASE
											WHEN [LB].[diff_backup_date] IS NULL 
											THEN N'NEVER' 
											ELSE CONVERT(VARCHAR(20), [LB].[diff_backup_date], 120) END
								ELSE N'' END
						+ CASE 
								WHEN [C].[backup_check_tran_hour] IS NOT NULL 
								THEN N'; last_tran=' 
									+ CASE
											WHEN [LB].[tran_backup_date] IS NULL 
											THEN N'NEVER' 
											ELSE CONVERT(VARCHAR(20), [LB].[tran_backup_date], 120) END
								ELSE N'' END AS [message]
					,[C].[name]
		FROM sys.databases [DB]
			INNER JOIN [_dbaid].[dbo].[config_database_SL1] [C]
				ON [DB].[name] = [C].[name] COLLATE DATABASE_DEFAULT
			INNER JOIN @last_backup [LB]
				ON [DB].[name] = [LB].[name] COLLATE DATABASE_DEFAULT
			LEFT OUTER JOIN @HADR_backup_info [CTE] 
				ON [DB].[name] = [CTE].[database_name] COLLATE DATABASE_DEFAULT
		WHERE [C].[backup_check_enabled] = 1
			AND [DB].[name] <> N'tempdb'
			AND [DB].[state_desc] = N'ONLINE'
			AND [DB].[is_in_standby] = 0;

	IF (SELECT COUNT(*) FROM @check_output WHERE [state] != 'OK') = 0
	BEGIN
		SELECT @backup_enabled = COUNT(*) FROM [_dbaid].[dbo].[config_database_SL1] WHERE [backup_check_enabled] = 1 AND [name] <> N'tempdb';
		SELECT @backup_disabled = COUNT(*) FROM [_dbaid].[dbo].[config_database_SL1] WHERE [backup_check_enabled] = 0 AND [name] <> N'tempdb';

		INSERT INTO @check_output VALUES('NA', N'Monitoring databases for backup(s)'
			+ N'; enabled=' + CAST(@backup_enabled AS NVARCHAR(8)) 
			+ N'; disabled=' + CAST(@backup_disabled AS NVARCHAR(8))
			, N'');
	END

	/* For Checkmk
	SELECT [state], [message] FROM @check_output WHERE [state] != 'OK';
	--*/

	/* For anything that scrapes the Windows Event Log or SQL ERRORLOG. */
	IF (@write_event_log = 1) OR (@write_errorlog = 1)
	BEGIN
		DECLARE @ErrorMsg NVARCHAR(2048), @State NVARCHAR(13), @Name sysname;
		DECLARE ErrorCurse CURSOR FAST_FORWARD FOR 
			SELECT [state], [state] + N' - ' + ISNULL(OBJECT_NAME(@@PROCID), N'DBAid Checks') + N' - ' + [message], [name]
			FROM @check_output;

		OPEN ErrorCurse;
		FETCH NEXT FROM ErrorCurse INTO @State, @ErrorMsg, @Name;

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			/* Checkmk uses CRITICAL; xp_logevent uses ERROR. 
			   Checkmk uses OK; xp_logevent uses INFORMATIONAL.
			*/
			IF @State = N'CRITICAL'
				SET @State = N'ERROR';
			ELSE IF @State = N'OK'
							SET @State = N'INFORMATIONAL';

			/* Generate event for items configured for WARNING. */
			IF (@State = N'WARNING' AND ((SELECT [backup_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE @Name = [name]) = 0))
			BEGIN
				/* Log event for SL1 to generate an Event from. */
				SELECT @ErrorMsg = N'BKUPDUE: ' + @ErrorMsg;
				IF (@write_event_log = 1)
				  EXEC xp_logevent 9075001, @ErrorMsg, @State;
				IF (@write_errorlog = 1)
				  RAISERROR (@ErrorMsg, 10, 105) WITH LOG;
      
				/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
				UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
				SET [backup_alert_fired] = 1
				WHERE [name] = @Name;
			END
			/* Generate event for items configured for CRITICAL. */
			ELSE IF (@State = N'ERROR' AND ((SELECT [backup_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE @Name = [name]) = 0))
						BEGIN
							/* Log event for SL1 to generate an Event from. */
							SELECT @ErrorMsg = N'BKUPDUE: ' + @ErrorMsg;
							IF (@write_event_log = 1)
							  EXEC xp_logevent 9075002, @ErrorMsg, @State;
							IF (@write_errorlog = 1)
							  RAISERROR (@ErrorMsg, 10, 111) WITH LOG;
       
							/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
							UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
							SET [backup_alert_fired] = 1
							WHERE [name] = @Name;
						END
						ELSE IF @State = N'INFORMATIONAL' AND ((SELECT [backup_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE @Name = [name]) = 1)
									BEGIN
										/* 20241217: Self-healing. No go. If there are multiple missed backup SL1 Events for a given instance, this Event will close _all_ of them, even if only one DB has been sorted.
											 EXEC xp_logevent 9075xxx, @ErrorMsg, @State;
										*/
										IF (@write_errorlog = 1)
										  RAISERROR (@ErrorMsg, 10, 1) WITH LOG;

										/* Flip bit to indicate alert condition has cleared. */
										UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
										SET [backup_alert_fired] = 0
										WHERE [name] = @Name;
									END

			FETCH NEXT FROM ErrorCurse INTO @State, @ErrorMsg, @Name;
		END

		CLOSE ErrorCurse;
		DEALLOCATE ErrorCurse;

		/* If there have been multiple databases with issue but not all have been resolved, make sure bits are flipped for those that are. */
		UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
		SET [backup_alert_fired] = 0
		WHERE [name] NOT IN (SELECT [name] FROM @check_output)
			AND [backup_alert_fired] = 1;
	END
	REVERT;
END
GO




USE [_dbaid];
GO
IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'check_integrity_SL1' AND [schema_id] = SCHEMA_ID('check') AND [type] = 'P')
BEGIN
	EXEC sp_executesql N'CREATE PROCEDURE [check].[check_integrity_SL1] AS RETURN 0;';
END
GO
ALTER PROCEDURE [check].[check_integrity_SL1]
(
	@write_event_log BIT = 1,
	@write_errorlog BIT = 0
)
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;

	EXECUTE AS LOGIN = N'_dbaid_sa';

	DECLARE @dbcheckdb INT, @dbnotcheckdb INT;
	DECLARE @check_output TABLE([state] VARCHAR(8), [message] NVARCHAR(4000), [name] sysname);

	IF OBJECT_ID('tempdb..#dbccinfo') IS NOT NULL 
		DROP TABLE #dbccinfo;

	CREATE TABLE #dbccinfo 
		([parent_object] NVARCHAR(255)
		,[object] NVARCHAR(255)
		,[field] NVARCHAR(255)
		,[value] NVARCHAR(255)
		,[db_name] NVARCHAR(128) NULL);

	EXECUTE [dbo].[foreachdb] N'USE [?];
		INSERT #dbccinfo ([parent_object], [object], [field], [value]) EXEC (''DBCC DBINFO() WITH TABLERESULTS, NO_INFOMSGS'');
		UPDATE #dbccinfo SET [db_name] = N''?'' WHERE [db_name] IS NULL;';

	;WITH [DbccDataSet] AS
	(
		SELECT [CD].[name]
					,[CD].[integrity_check_alert]
					,CAST([CD].[integrity_check_hour] AS NUMERIC(5,2)) AS [integrity_check_hour]
					,[DB].[create_date] AS [db_create_date]
					,CAST([DI].[value] AS DATETIME) AS [last_dbcc_datetime]
		FROM [sys].[databases] [DB]
			LEFT JOIN #dbccinfo [DI]
				ON [DB].[name] = [DI].[db_name] COLLATE DATABASE_DEFAULT
			LEFT JOIN [_dbaid].[dbo].[config_database_SL1] [CD]
				ON [DB].[name] = [CD].[name] COLLATE DATABASE_DEFAULT
			WHERE [DI].[field] = 'dbi_dbccLastKnownGood'
				AND [CD].[integrity_check_enabled] = 1
				AND [DB].[name] <> N'tempdb'
	)
	INSERT INTO @check_output
		SELECT CASE WHEN [last_dbcc_datetime] < DATEADD(HOUR, -[integrity_check_hour], GETDATE()) 
									AND [db_create_date] < DATEADD(HOUR, -[integrity_check_hour], GETDATE()) /* Grace period for newly created databases. */
								THEN [integrity_check_alert] 
								ELSE N'OK' END AS [state]
					,'database=' 
						+ QUOTENAME([name])
						+ '; last_checkdb=' 
						+ CASE WHEN [last_dbcc_datetime] IS NULL OR [last_dbcc_datetime] < [db_create_date] THEN 'NEVER'
										ELSE CONVERT(NVARCHAR(20), [last_dbcc_datetime], 120) END AS [message]
					,[name]
		FROM [DbccDataSet]
		ORDER BY [name];

	IF (SELECT COUNT(*) FROM @check_output WHERE [state] != 'OK') = 0
	BEGIN
		SELECT @dbcheckdb = COUNT(*) 
		FROM [_dbaid].[dbo].[config_database_SL1] 
		WHERE [integrity_check_enabled] = 1
			AND [name] <> N'tempdb';

		SELECT @dbnotcheckdb=COUNT(*) 
		FROM [_dbaid].[dbo].[config_database_SL1] 
		WHERE [integrity_check_enabled] = 0
			AND [name] <> N'tempdb';

		INSERT INTO @check_output 
		VALUES('NA', CAST(@dbcheckdb AS NVARCHAR(10)) + ' database(s) monitored, ' + CAST(@dbnotcheckdb AS NVARCHAR(10)) + ' database(s) opted-out', N'');
	END 

	/* For Checkmk.
	SELECT [state], [message] FROM @check_output WHERE [state] NOT IN ('OK');
	--*/

	/* For anything that scrapes the Windows Event Log or SQL ERRORLOG. */
	IF (@write_event_log = 1) OR (@write_errorlog = 1)
	BEGIN
		DECLARE @ErrorMsg NVARCHAR(2048), @State NVARCHAR(13), @Name sysname;
		DECLARE ErrorCurse CURSOR FAST_FORWARD FOR
			SELECT [state], [state] + N' - ' + ISNULL(OBJECT_NAME(@@PROCID), N'DBAid Checks') + N' - ' + [message], [name]
			FROM @check_output;

		OPEN ErrorCurse;
		FETCH NEXT FROM ErrorCurse INTO @State, @ErrorMsg, @Name;

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			/* Checkmk uses CRITICAL; xp_logevent uses ERROR. 
			   Checkmk uses OK; xp_logevent uses INFORMATIONAL.
			*/
			IF @State = N'CRITICAL'
				SET @State = N'ERROR';
			ELSE IF @State = N'OK'
						SET @State = N'INFORMATIONAL';

		/* Generate event for items configured for WARNING. */
		IF (@State = N'WARNING' AND (SELECT [integrity_check_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE @Name = [name]) = 0)
		BEGIN
			/* Log event for SL1 to generate an Event from. */
			SELECT @ErrorMsg = N'DBCCDUE: ' + @ErrorMsg;
			IF (@write_event_log = 1)
			  EXEC xp_logevent 9075005, @ErrorMsg, @State;
			IF (@write_errorlog = 1)
			  RAISERROR (@ErrorMsg, 10, 105) WITH LOG;
      
			/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
			UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
			SET [integrity_check_alert_fired] = 1
			WHERE [name] = @Name;
		END
		/* Generate event for items configured for CRITICAL. */
		ELSE IF (@State = N'ERROR' AND (SELECT [integrity_check_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE @Name = [name]) = 0)
					BEGIN
						/* Log event for SL1 to generate an Event from. */
						SELECT @ErrorMsg = N'DBCCDUE: ' + @ErrorMsg;
						IF (@write_event_log = 1)
						  EXEC xp_logevent 9075006, @ErrorMsg, @State;
						IF (@write_errorlog = 1)
						  RAISERROR (@ErrorMsg, 10, 111) WITH LOG;
       
						/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
						UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
						SET [integrity_check_alert_fired] = 1
						WHERE [name] = @Name;
					END
					ELSE IF (@State = N'INFORMATIONAL' AND (SELECT [integrity_check_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE @Name = [name]) = 1)
								BEGIN
									/* 20241217: Self-healing. No go. If there are multiple integrity checks SL1 Events for a given instance, this Event will close _all_ of them, even if only one DB has been sorted.
									   EXEC xp_logevent 9075xxx, @ErrorMsg, @State;
									*/
									IF (@write_errorlog = 1)
									  RAISERROR (@ErrorMsg, 10, 1) WITH LOG;

									/* Flip bit to indicate alert condition has cleared. */
									UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
									SET [integrity_check_alert_fired] = 0
									WHERE [name] = @Name;
								END

			FETCH NEXT FROM ErrorCurse INTO @State, @ErrorMsg, @Name;
		END

		CLOSE ErrorCurse;
		DEALLOCATE ErrorCurse;
	END
	REVERT;
END
GO





USE [_dbaid];
GO
IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'check_agentjob_SL1' AND [schema_id] = SCHEMA_ID('check') AND [type] = 'P')
BEGIN
	EXEC sp_executesql N'CREATE PROCEDURE [check].[check_agentjob_SL1] AS RETURN 0;';
END
GO
ALTER PROCEDURE [check].[check_agentjob_SL1]
(
	@write_event_log BIT = 1,
	@write_errorlog BIT = 0
)
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;

	EXECUTE AS LOGIN = N'_dbaid_sa';

	DECLARE @countjob INT, @runtimejob INT, @failstatusjob INT, @cancelstatusjob INT;
	DECLARE @check_output TABLE([state] VARCHAR(8), [message] NVARCHAR(4000), [name] sysname, [whatfailure] varchar(8));

	DECLARE @jobactivity TABLE (
			[session_id] INT NULL
			,[job_id] UNIQUEIDENTIFIER NULL
			,[job_name] SYSNAME NULL
			,[run_requested_date] DATETIME NULL
			,[run_requested_source] SYSNAME NULL
			,[queued_date] DATETIME NULL
			,[start_execution_date] DATETIME NULL
			,[last_executed_step_id] INT NULL
			,[last_executed_step_date] DATETIME NULL
			,[stop_execution_date] DATETIME NULL
			,[next_scheduled_run_date] DATETIME NULL
			,[job_history_id] INT NULL
			,[message] NVARCHAR(1024) NULL
			,[run_status] INT NULL
			,[operator_id_emailed] INT NULL
			,[operator_id_netsent] INT NULL
			,[operator_id_paged] INT NULL
	);

	SELECT @countjob = COUNT(*)
	FROM [msdb].[dbo].[sysjobs]
	WHERE [enabled] = 1;

	SELECT @runtimejob = COUNT(*)
	FROM [_dbaid].[dbo].[config_agentjob_SL1] [c]
		INNER JOIN [msdb].[dbo].[sysjobs] [j]
			ON [c].[name] = [j].[name] COLLATE DATABASE_DEFAULT
	WHERE [j].[enabled] = 1
		AND [c].[runtime_check_enabled] = 1;

	SELECT @failstatusjob = COUNT(*)
	FROM [_dbaid].[dbo].[config_agentjob_SL1] [c]
		INNER JOIN [msdb].[dbo].[sysjobs] [j]
			ON [c].[name] = [j].[name] COLLATE DATABASE_DEFAULT
	WHERE [j].[enabled] = 1
		AND [c].[state_fail_check_enabled] = 1;

	SELECT @cancelstatusjob = COUNT(*)
	FROM [_dbaid].[dbo].[config_agentjob_SL1] [c]
		INNER JOIN [msdb].[dbo].[sysjobs] [j]
			ON [c].[name] = [j].[name] COLLATE DATABASE_DEFAULT
	WHERE [j].[enabled] = 1
		AND [c].[state_cancel_check_enabled] = 1;

	IF NOT ((SELECT LOWER(CAST(SERVERPROPERTY('Edition') AS VARCHAR(128)))) LIKE '%express%')
	BEGIN
		INSERT INTO @jobactivity 
			EXEC msdb.dbo.sp_help_jobactivity;
	END
	ELSE
	BEGIN
		INSERT INTO @check_output 
		VALUES('NA', 'SQL Server Express Edition detected.', N'', N'');
	END

	;WITH [job_data]
	AS
	(
		SELECT ROW_NUMBER() OVER (PARTITION BY [J].[name] ORDER BY [H].[run_date] DESC, [H].[run_time] DESC) AS [row]
			,[J].[job_id]
			,[J].[name]
			,CASE [H].[run_status]
					WHEN 0 THEN 'FAIL'
					WHEN 1 THEN 'SUCCESS'
					WHEN 2 THEN 'RETRY'
					WHEN 3 THEN 'CANCEL'
					ELSE 'UNKNOWN' END AS [run_status]
			,[run_datetime] = CAST(CAST([H].[run_date] AS CHAR(8)) + ' ' + STUFF(STUFF(REPLACE(STR([H].[run_time], 6, 0), ' ', '0'), 3, 0, ':'), 6, 0, ':') AS DATETIME)
			,[H].[run_duration]
		FROM [msdb].[dbo].[sysjobs] [J]
		LEFT JOIN [msdb].[dbo].[sysjobhistory] [H]
			ON [J].[job_id] = [H].[job_id]
		WHERE [J].[enabled] = 1
			AND ([H].[step_id] = 0 OR [H].[step_id] IS NULL)
	)
	INSERT INTO @check_output
		SELECT CASE 
							WHEN [C].[runtime_check_enabled] = 1 /* If a non-continuous job is running and exceeded the configured runtime, raise alert  */
								AND [C].[is_continuous_running_job] = 0
								AND [X].[start_execution_date] IS NOT NULL 
								AND [X].[stop_execution_date] IS NULL 
								AND CAST(DATEDIFF(MINUTE,[X].[start_execution_date],GETDATE()) AS VARCHAR(10)) > [C].[runtime_check_min] 
								THEN [C].[runtime_check_alert] 
							WHEN (([C].[state_fail_check_enabled] = 1 AND [J].[run_status] = 'FAIL') OR ([C].[state_cancel_check_enabled] = 1 AND [J].[run_status] = 'CANCEL'))
								THEN CASE /* Job status reports as failed or canceled */
												WHEN [C].[is_continuous_running_job] = 0 /* If job is not continuous, raise alert */
													THEN [C].[state_check_alert] 
												WHEN [C].[is_continuous_running_job] = 1 AND [X].[stop_execution_date] IS NOT NULL /* If job is continuous and not running, raise alert */
													THEN [C].[state_check_alert] 
												WHEN [C].[is_continuous_running_job] = 1 AND [X].[stop_execution_date] IS NULL /* If job is continuous and currently running, clear alert */
													THEN 'OK' /* Covers where a job is continuous running, currently running, and last status was FAIL or CANCEL; without this, NULL is returned. */
										END
							ELSE 'OK' END AS [state]
					,'job=' + QUOTENAME([J].[name]) COLLATE DATABASE_DEFAULT
						+ CASE 
								WHEN [C].[state_fail_check_enabled] = 1 
									OR [C].[state_cancel_check_enabled] = 1 
									THEN ';state='
								ELSE '' END
						+ CASE 
								WHEN [X].[start_execution_date] IS NOT NULL 
									AND [X].[stop_execution_date] IS NULL
									THEN 'RUNNING' 
									ELSE [J].[run_status] END
						+ CASE 
								WHEN [C].[runtime_check_enabled] = 1 
									THEN ';runtime_min=' 
						+ CASE 
								WHEN [X].[start_execution_date] IS NOT NULL 
									AND [X].[stop_execution_date] IS NULL
									THEN CAST(DATEDIFF(MINUTE,[X].[start_execution_date],GETDATE()) AS VARCHAR(10))
									ELSE CAST(CAST(ROUND([J].[run_duration]/100.00%100, 2) AS NUMERIC(18,2)) AS VARCHAR(10)) END
						+ ';runtime_check_min=' 
						+ CAST([C].[runtime_check_min] AS VARCHAR(10))
						ELSE '' END AS [message]
					,[J].[name]
					,CASE 
							WHEN [C].[runtime_check_enabled] = 1 AND [X].[start_execution_date] IS NOT NULL AND [X].[stop_execution_date] IS NULL AND [C].[is_continuous_running_job] = 0 AND CAST(DATEDIFF(MINUTE,[X].[start_execution_date],GETDATE()) AS VARCHAR(10)) > [C].[runtime_check_min] THEN 'LONGRUN'
							WHEN (([C].[state_fail_check_enabled] = 1 AND [J].[run_status] = 'FAIL') OR ([C].[state_cancel_check_enabled] = 1 AND [J].[run_status] = 'CANCEL')) THEN 'JOBFAIL'
							ELSE 'UNKNOWN'
						END AS [whatfailure]
		FROM [job_data] [J]
			INNER JOIN [_dbaid].[dbo].[config_agentjob_SL1] [C]
				ON [J].[name] = [C].[name] COLLATE DATABASE_DEFAULT
			LEFT JOIN @jobactivity [X]
				ON [J].[job_id] = [X].[job_id]
		WHERE [J].[row] = 1
			AND (([C].[state_fail_check_enabled] = 1 
							AND [J].[run_status] = 'FAIL')
						OR ([C].[state_cancel_check_enabled] = 1 
								AND [J].[run_status] = 'CANCEL')
						OR ([C].[runtime_check_enabled] = 1 
								AND [X].[start_execution_date] IS NOT NULL 
								AND [X].[stop_execution_date] IS NULL 
								AND CAST(DATEDIFF(MINUTE,[X].[start_execution_date],GETDATE()) AS VARCHAR(10)) > [C].[runtime_check_min]));

	IF ((SELECT COUNT(*) FROM @check_output) = 0)
	BEGIN
		IF (@countjob > 0)
			INSERT INTO @check_output 
				VALUES('OK', CAST(@countjob AS VARCHAR(10)) + ' agent job(s) enabled; ' 
				+ CAST(@failstatusjob AS VARCHAR(10)) + ' monitor fail status; ' 
				+ CAST(@cancelstatusjob AS VARCHAR(10)) + ' monitor cancel status; ' 
				+ CAST(@runtimejob AS VARCHAR(10)) + ' monitor runtime', N'', N'');
		ELSE
			INSERT INTO @check_output 
			VALUES('NA', 'No agent job(s) enabled;', N'', N'');
	END

	/* For Checkmk monitoring.
	SELECT [state], [message] FROM @check_output;
	--*/

	IF (@write_event_log = 1) OR (@write_errorlog = 1)
	BEGIN
		/* Update config_agentjob_alerts_fired_SL1 table to reflect any jobs*/

		DECLARE @ErrorMsg NVARCHAR(2048), @State NVARCHAR(13), @Name sysname, @WhatFailure varchar(8);
		DECLARE ErrorCurse CURSOR FAST_FORWARD FOR 
			SELECT [state], [state] + N' - ' + ISNULL(OBJECT_NAME(@@PROCID), N'DBAid Checks') + N' - ' + [message], [name], [whatfailure] 
			FROM @check_output;

		OPEN ErrorCurse;
		FETCH NEXT FROM ErrorCurse INTO @State, @ErrorMsg, @Name, @WhatFailure;

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			/* Checkmk uses CRITICAL; xp_logevent uses ERROR. 
			   Checkmk uses OK; xp_logevent uses INFORMATIONAL.
			*/
			IF @State = N'CRITICAL'
				SET @State = N'ERROR';
			ELSE IF @State = N'OK'
							SET @State = N'INFORMATIONAL';

			IF @WhatFailure = 'JOBFAIL'
				/* Flip bit for long running alert as it is no longer relevant (the job has failed or been cancelled, so is no longer long-running).  */
				UPDATE [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1]
				SET [job_long_running_alert_fired] = 0
				WHERE [name] = @Name
					AND [job_long_running_alert_fired] = 1;

			/* Generate event for items configured for WARNING. */
			IF (@State = N'WARNING' AND @WhatFailure = 'JOBFAIL' AND ((SELECT [job_fail_alert_fired] FROM [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1] WHERE @Name = [name]) = 0))
			BEGIN
				/* Log event for SL1 to generate an Event from. */
				SELECT @ErrorMsg = @WhatFailure + N': ' + @ErrorMsg;
				IF (@write_event_log = 1)
				  EXEC xp_logevent 9075008, @ErrorMsg, @State;
				IF (@write_errorlog = 1)
				  RAISERROR (@ErrorMsg, 10, 105) WITH LOG;

				/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
				UPDATE [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1]
				SET [job_fail_alert_fired] = 1
				WHERE [name] = @Name;
			END
			ELSE IF (@State = N'WARNING' AND @WhatFailure = 'LONGRUN' AND ((SELECT [job_long_running_alert_fired] FROM [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1] WHERE @Name = [name]) = 0))
						BEGIN
							/* Log event for SL1 to generate an Event from. */
							SELECT @ErrorMsg = @WhatFailure + N': ' + @ErrorMsg;
							IF (@write_event_log = 1)
							  EXEC xp_logevent 9075008, @ErrorMsg, @State;
							IF (@write_errorlog = 1)
							  RAISERROR (@ErrorMsg, 10, 105) WITH LOG;

							/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
							UPDATE [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1]
							SET [job_long_running_alert_fired] = 1
							WHERE [name] = @Name;
						END
						/* Generate event for items configured for CRITICAL. */
						ELSE IF (@State = N'ERROR' AND @WhatFailure = 'JOBFAIL' AND ((SELECT [job_fail_alert_fired] FROM [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1] WHERE @Name = [name]) = 0))
									BEGIN
										/* Log event for SL1 to generate an Event from. */
										SELECT @ErrorMsg = @WhatFailure + N': ' + @ErrorMsg;
										IF (@write_event_log = 1)
										  EXEC xp_logevent 9075009, @ErrorMsg, @State;
										IF (@write_errorlog = 1)
										  RAISERROR (@ErrorMsg, 10, 111) WITH LOG;
             
										/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
										UPDATE [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1]
										SET [job_fail_alert_fired] = 1
										WHERE [name] = @Name;
									END
									ELSE IF (@State = N'ERROR' AND @WhatFailure = 'LONGRUN' AND ((SELECT [job_long_running_alert_fired] FROM [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1] WHERE @Name = [name]) = 0))
									BEGIN
										/* Log event for SL1 to generate an Event from. */
										SELECT @ErrorMsg = @WhatFailure + N': ' + @ErrorMsg;
										IF (@write_event_log = 1)
										  EXEC xp_logevent 9075009, @ErrorMsg, @State;
										IF (@write_errorlog = 1)
										  RAISERROR (@ErrorMsg, 10, 111) WITH LOG;
             
										/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
										UPDATE [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1]
										SET [job_long_running_alert_fired] = 1
										WHERE [name] = @Name;
									END
									ELSE IF @State = N'INFORMATIONAL' OR @State = N'NA' 
												BEGIN
												  IF (@write_errorlog = 1)
												    RAISERROR (@ErrorMsg, 10, 1) WITH LOG;

													/* Flip bits to indicate alert conditions have cleared. */
													UPDATE [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1]
													SET [job_fail_alert_fired] = 0
													WHERE [name] = @Name;

													UPDATE [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1]
													SET [job_long_running_alert_fired] = 0
													WHERE [name] = @Name;
												END

			FETCH NEXT FROM ErrorCurse INTO @State, @ErrorMsg, @Name, @WhatFailure;
		END

		CLOSE ErrorCurse;
		DEALLOCATE ErrorCurse;

		/* If there have been multiple issues but not all have been resolved, make sure bits are flipped for those that are. */
		UPDATE [_dbaid].[dbo].[config_agentjob_alerts_fired_SL1]
		SET [job_fail_alert_fired] = 0, [job_long_running_alert_fired] = 0
		WHERE [name] NOT IN (SELECT [name] FROM @check_output)
			AND ([job_fail_alert_fired] = 1 OR [job_long_running_alert_fired] = 1);
	END
	REVERT;
END
GO



USE [_dbaid];
GO
IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'logshipping_SL1' AND [schema_id] = SCHEMA_ID('check') AND [type] = 'P')
BEGIN
	EXEC sp_executesql N'CREATE PROCEDURE [check].[logshipping_SL1] AS RETURN 0;';
END
GO
ALTER PROCEDURE [check].[logshipping_SL1]
(
	@write_event_log BIT = 1,
	@write_errorlog BIT = 0
)
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;

	EXECUTE AS LOGIN = N'_dbaid_sa';

	DECLARE @check_output TABLE([state] VARCHAR(8), [message] NVARCHAR(4000), [name] sysname);

	DECLARE @primarycount INT;
	DECLARE @secondarycount INT;
	DECLARE @curdate_utc DATETIME;

	SELECT @curdate_utc = GETUTCDATE();

	SELECT @primarycount = COUNT(*)
	FROM [msdb].[dbo].[log_shipping_monitor_primary] [L]
		INNER JOIN [dbo].[config_database_SL1] [C]
				ON [L].[primary_database] = [C].[name] COLLATE DATABASE_DEFAULT
	WHERE [C].[logshipping_check_enabled] = 1;

	SELECT @secondarycount = COUNT(*)
	FROM [msdb].[dbo].[log_shipping_monitor_secondary] [L]
		INNER JOIN [dbo].[config_database_SL1] [C]
				ON [L].[primary_database] = [C].[name] COLLATE DATABASE_DEFAULT
	WHERE [C].[logshipping_check_enabled] = 1;

	INSERT INTO @check_output
		SELECT CASE WHEN DATEDIFF(HOUR, [L].[last_backup_date_utc], @curdate_utc) >= [C].[logshipping_check_hour]  
				THEN [C].[logshipping_check_alert] ELSE 'OK' END AS [state]
			,'database=' 
			+ QUOTENAME([L].[primary_database]) COLLATE DATABASE_DEFAULT 
			+ '; role=PRIMARY; last_backup_minago=' 
			+ CAST(DATEDIFF(MINUTE, [L].[last_backup_date_utc], @curdate_utc) AS NVARCHAR(10)) AS [message]
			,C.[name]
		FROM [msdb].[dbo].[log_shipping_monitor_primary] [L]
			INNER JOIN [dbo].[config_database_SL1] [C]
					ON [L].[primary_database] = [C].[name] COLLATE DATABASE_DEFAULT
		WHERE [C].[logshipping_check_enabled] = 1
			AND DATEDIFF(MINUTE, [L].[last_backup_date_utc], @curdate_utc) > [L].[backup_threshold]
		UNION ALL
		SELECT CASE WHEN DATEDIFF(HOUR, [L].[last_restored_date_utc], @curdate_utc) >= [C].[logshipping_check_hour] 
				THEN [C].[logshipping_check_alert] ELSE 'OK' END AS [state]
			,'database=' + QUOTENAME([L].[secondary_database]) COLLATE DATABASE_DEFAULT 
			+ '; role=SECONDARY; primary_source=' + QUOTENAME([L].[primary_server]) 
			+ '.' + QUOTENAME([L].[primary_database])
			+ '; last_restore_minago=' + CAST(DATEDIFF(MINUTE, [L].[last_restored_date_utc], @curdate_utc) AS NVARCHAR(10)) AS [message]
			,C.[name]
		FROM [msdb].[dbo].[log_shipping_monitor_secondary] [L]
			INNER JOIN [dbo].[config_database_SL1] [C]
					ON [L].[secondary_database] = [C].[name] COLLATE DATABASE_DEFAULT
		WHERE [C].[logshipping_check_enabled] = 1
			AND DATEDIFF(MINUTE, [L].[last_restored_date_utc], @curdate_utc) > [L].[restore_threshold]
		ORDER BY [message];

	IF (SELECT COUNT(*) FROM @check_output) < 1 AND (@primarycount > 0 OR @secondarycount > 0)
		INSERT INTO @check_output 
		VALUES('NA', CAST(@primarycount AS NVARCHAR(10)) + ' primary database(s), ' + CAST(@secondarycount AS NVARCHAR(10)) + ' secondary database(s).', N'');
	ELSE IF (SELECT COUNT(*) FROM @check_output) < 1
		INSERT INTO @check_output 
		VALUES('NA', 'Logshipping is currently not configured.', N'');

	/* For Checkmk
	SELECT [state], [message] FROM @check_output;
	--*/

	/* For anything that scrapes the Windows Event Log or SQL ERRORLOG. */
	IF (@write_event_log = 1) OR (@write_errorlog = 1)
	BEGIN
		DECLARE @ErrorMsg NVARCHAR(2048), @State NVARCHAR(13), @Name sysname;
		DECLARE ErrorCurse CURSOR FAST_FORWARD FOR 
			SELECT [state], [state] + N' - ' + ISNULL(OBJECT_NAME(@@PROCID), N'DBAid Checks') + N' - ' + [message], [name]
			FROM @check_output 
			WHERE [state] NOT IN ('NA');

		OPEN ErrorCurse;
		FETCH NEXT FROM ErrorCurse INTO @State, @ErrorMsg, @Name;

		WHILE (@@FETCH_STATUS = 0)
		BEGIN
			/* Checkmk uses CRITICAL; xp_logevent uses ERROR. 
			   Checkmk uses OK; xp_logevent uses INFORMATIONAL.
			*/
			IF @State = N'CRITICAL'
				SET @State = N'ERROR';
			ELSE IF @State = N'OK'
							SET @State = N'INFORMATIONAL';

			/* Generate event for items configured for WARNING. */
			IF (@State = N'WARNING' AND ((SELECT [logshipping_check_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE @Name = [name]) = 0))
			BEGIN
				/* Log event for SL1 to generate an Event from. */
				SELECT @ErrorMsg = N'LOGSHIP: ' + @ErrorMsg;
				IF (@write_event_log = 1)
				  EXEC xp_logevent 9075012, @ErrorMsg, @State;
				IF (@write_errorlog = 1)
				  RAISERROR (@ErrorMsg, 10, 105) WITH LOG;
      
				/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
				UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
				SET [logshipping_check_alert_fired] = 1
				WHERE [name] = @Name;
			END
			/* Generate event for items configured for CRITICAL. */
			ELSE IF (@State = N'ERROR' AND ((SELECT [logshipping_check_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE @Name = [name]) = 0))
						BEGIN
							/* Log event for SL1 to generate an Event from. */
							SELECT @ErrorMsg = N'LOGSHIP: ' + @ErrorMsg;
							IF (@write_event_log = 1)
							  EXEC xp_logevent 9075013, @ErrorMsg, @State;
							IF (@write_errorlog = 1)
							  RAISERROR (@ErrorMsg, 10, 111) WITH LOG;
       
							/* Flip bit to indicate alert has fired so we do not flood Event Log/SL1/DBAs with repeat events. */
							UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
							SET [logshipping_check_alert_fired] = 1
							WHERE [name] = @Name;
						END
						ELSE IF (@State = N'INFORMATIONAL' AND (SELECT [logshipping_check_alert_fired] FROM [_dbaid].[dbo].[config_db_alerts_fired_SL1] WHERE [name] = @Name) = 1)
									BEGIN
										/* 20241217: Self-healing. No go. If there are multiple missed backup SL1 Events for a given instance, this Event will close _all_ of them, even if only one DB has been sorted.
											 EXEC xp_logevent 9075xxx, @ErrorMsg, @State;
										*/
										IF (@write_errorlog = 1)
										  RAISERROR (@ErrorMsg, 10, 1) WITH LOG;

										/* Flip bit to indicate alert condition has cleared. */
										UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
										SET [logshipping_check_alert_fired] = 0
										WHERE [name] = @Name;
									END

			FETCH NEXT FROM ErrorCurse INTO @State, @ErrorMsg, @Name;
		END

		CLOSE ErrorCurse;
		DEALLOCATE ErrorCurse;

		/* If there have been multiple issues but not all have been resolved, make sure bits are flipped for those that are. */
		UPDATE [_dbaid].[dbo].[config_db_alerts_fired_SL1]
		SET [logshipping_check_alert_fired] = 0
		WHERE [name] NOT IN (SELECT [name] FROM @check_output)
			AND [logshipping_check_alert_fired] = 1;

	END
	REVERT;
END
GO





USE [msdb]
GO
IF EXISTS (SELECT 1 FROM msdb..sysjobs WHERE [name] = N'_dbaid_SL1_inventory')
	EXEC msdb..sp_delete_job @job_name = N'_dbaid_SL1_inventory';
IF EXISTS (SELECT 1 FROM msdb..sysschedules WHERE [name] = N'_dbaid_SL1_inventory')
	EXEC msdb..sp_delete_schedule @schedule_name = N'_dbaid_SL1_inventory';
GO

DECLARE @sa_login sysname;
SELECT @sa_login = [name] FROM sys.server_principals WHERE [sid] = 0x1;

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'_dbaid_SL1_inventory', 
	@enabled=0, 
	@notify_level_eventlog=0, 
	@notify_level_email=0, 
	@notify_level_netsend=0, 
	@notify_level_page=0, 
	@delete_level=0, 
	@description=N'Job to check for new/dropped databases/jobs. Updates tables used for SL1 monitoring accordingly.', 
	@category_name=N'_dbaid maintenance', 
	@owner_login_name=@sa_login, @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run database inventory', 
	@step_id=1, 
	@cmdexec_success_code=0, 
	@on_success_action=3, 
	@on_success_step_id=0, 
	@on_fail_action=2, 
	@on_fail_step_id=0, 
	@retry_attempts=0, 
	@retry_interval=0, 
	@os_run_priority=0, @subsystem=N'TSQL', 
	@command=N'EXEC [_dbaid].[check].[inventory_database_SL1];', 
	@database_name=N'master', 
	@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run job inventory', 
	@step_id=2, 
	@cmdexec_success_code=0, 
	@on_success_action=1, 
	@on_success_step_id=0, 
	@on_fail_action=2, 
	@on_fail_step_id=0, 
	@retry_attempts=0, 
	@retry_interval=0, 
	@os_run_priority=0, @subsystem=N'TSQL', 
	@command=N'EXEC [_dbaid].[check].[inventory_agentjob_SL1];', 
	@database_name=N'master', 
	@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'_dbaid_SL1_inventory', 
	@enabled=1, 
	@freq_type=4, 
	@freq_interval=1, 
	@freq_subday_type=4, 
	@freq_subday_interval=15, 
	@freq_relative_interval=0, 
	@freq_recurrence_factor=0, 
	@active_start_date=20241218, 
	@active_end_date=99991231, 
	@active_start_time=200, 
	@active_end_time=235959 
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO




USE [msdb]
GO
IF EXISTS (SELECT 1 FROM msdb..sysjobs WHERE [name] = N'_dbaid_SL1_checks')
	EXEC msdb..sp_delete_job @job_name = N'_dbaid_SL1_checks';
IF EXISTS (SELECT 1 FROM msdb..sysschedules WHERE [name] = N'_dbaid_SL1_checks')
	EXEC msdb..sp_delete_schedule @schedule_name = N'_dbaid_SL1_checks';
GO

DECLARE @sa_login sysname;
SELECT @sa_login = [name] FROM sys.server_principals WHERE [sid] = 0x1;

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'_dbaid_SL1_checks', 
	@enabled=0, 
	@notify_level_eventlog=0, 
	@notify_level_email=0, 
	@notify_level_netsend=0, 
	@notify_level_page=0, 
	@delete_level=0, 
	@description=N'Runs check procedures. If any issues/errors are found, events are written to the Windows Application Event Log for SL1 to pick up and generate tickets.', 
	@category_name=N'_dbaid maintenance', 
	@owner_login_name=@sa_login, @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run backup check', 
	@step_id=1, 
	@cmdexec_success_code=0, 
	@on_success_action=3, 
	@on_success_step_id=0, 
	@on_fail_action=2, 
	@on_fail_step_id=0, 
	@retry_attempts=0, 
	@retry_interval=0, 
	@os_run_priority=0, @subsystem=N'TSQL', 
	@command=N'EXEC [_dbaid].[check].[check_backup_SL1] @write_event_log = 1, @write_errorlog = 0;', 
	@database_name=N'master', 
	@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run integrity checks check', 
	@step_id=2, 
	@cmdexec_success_code=0, 
	@on_success_action=3, 
	@on_success_step_id=0, 
	@on_fail_action=2, 
	@on_fail_step_id=0, 
	@retry_attempts=0, 
	@retry_interval=0, 
	@os_run_priority=0, @subsystem=N'TSQL', 
	@command=N'EXEC [_dbaid].[check].[check_integrity_SL1] @write_event_log = 1, @write_errorlog = 0;', 
	@database_name=N'master', 
	@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run job check', 
	@step_id=3, 
	@cmdexec_success_code=0, 
	@on_success_action=1, 
	@on_success_step_id=0, 
	@on_fail_action=2, 
	@on_fail_step_id=0, 
	@retry_attempts=0, 
	@retry_interval=0, 
	@os_run_priority=0, @subsystem=N'TSQL', 
	@command=N'EXEC [_dbaid].[check].[check_agentjob_SL1] @write_event_log = 1, @write_errorlog = 0;', 
	@database_name=N'master', 
	@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'_dbaid_SL1_checks', 
	@enabled=1, 
	@freq_type=4, 
	@freq_interval=1, 
	@freq_subday_type=4, 
	@freq_subday_interval=5, 
	@freq_relative_interval=0, 
	@freq_recurrence_factor=0, 
	@active_start_date=20241218, 
	@active_end_date=99991231, 
	@active_start_time=300, 
	@active_end_time=235959 
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

/* Populate monitoring tables with database & job names, set default thresholds. */
USE [_dbaid];
IF EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'check_config' AND [schema_id] = SCHEMA_ID('maintenance') AND [type] = 'P')
	EXEC [_dbaid].[maintenance].[check_config]; /* Run default DBAid inventory to make sure things are up to date. */
WAITFOR DELAY '00:00:02';
EXEC [msdb].[dbo].[sp_start_job] @job_name = N'_dbaid_SL1_inventory';
WAITFOR DELAY '00:00:02'; /* Wait for tables to be populated with initial values before updating with existing thresholds. */
GO

/* Bring across any existing thresholds from existing monitoring configuration. */
USE [_dbaid];
GO
IF EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'config_database' AND [schema_id] = SCHEMA_ID('dbo') AND [type] = 'U') AND EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'config_database_SL1' AND [schema_id] = SCHEMA_ID('dbo') AND [type] = 'U')
	UPDATE t
	SET t.[database_check_alert] = s.[change_state_alert]
		,t.[backup_check_alert] = s.[backup_state_alert]
		,t.[backup_check_full_hour] = (CASE WHEN s.[backup_frequency_hours] = 0 THEN 26 ELSE s.[backup_frequency_hours] END)
		,t.[backup_check_diff_hour] = (CASE WHEN s.[backup_frequency_hours] = 0 THEN 26 ELSE s.[backup_frequency_hours] END)
		,t.[backup_check_enabled] = (CASE WHEN s.[backup_frequency_hours] = 0 THEN 0 ELSE 1 END)
		,t.[integrity_check_alert] = s.[checkdb_state_alert]
		,t.[integrity_check_hour] = (CASE WHEN s.[checkdb_frequency_hours] = 0 THEN 170 ELSE s.[checkdb_frequency_hours] END)
		,t.[integrity_check_enabled] = (CASE WHEN s.[checkdb_frequency_hours] = 0 THEN 0 ELSE 1 END)
		,t.[capacity_check_warning_free] = s.[capacity_warning_percent_free]
		,t.[capacity_check_critical_free] = s.[capacity_critical_percent_free]
	FROM [_dbaid].[dbo].[config_database_SL1] t
		INNER JOIN [_dbaid].[dbo].[config_database] s ON t.[name] = s.[db_name];
GO

IF EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'config_job' AND [schema_id] = SCHEMA_ID('dbo') AND [type] = 'U') AND EXISTS (SELECT 1 FROM sys.tables WHERE [name] = N'config_agentjob_SL1' AND [schema_id] = SCHEMA_ID('dbo') AND [type] = 'U')
	UPDATE t
	SET t.[state_check_alert] = s.[change_state_alert]
		,t.[runtime_check_min] = (CASE WHEN s.[max_exec_time_min] = 0 THEN 200 ELSE s.[max_exec_time_min] END)
		,t.[state_fail_check_enabled] = s.[is_enabled]
		,t.[state_cancel_check_enabled] = s.[is_enabled]
		,t.[runtime_check_enabled] = s.[is_enabled]
		,t.[is_continuous_running_job] = (CASE WHEN s.[max_exec_time_min] = 0 THEN 1 ELSE 0 END)
	FROM [_dbaid].[dbo].[config_agentjob_SL1] t
		INNER JOIN [_dbaid].[dbo].[config_job] s ON t.[name] = s.[job_name];
GO

/* Add version to version table; this patch brings equivalency to v6.5.1. */
IF NOT EXISTS (SELECT 1 FROM [_dbaid].[dbo].[version] WHERE [version] = N'$(Version)')
  INSERT INTO [_dbaid].[dbo].[version]([version]) VALUES('$(Version)');
GO