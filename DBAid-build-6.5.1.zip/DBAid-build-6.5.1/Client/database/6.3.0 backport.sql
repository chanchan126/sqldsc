﻿/* Primarily for SQL 2008 machines */

:setvar DatabaseName "_dbaid"
:setvar Tenant "Tenant"
:setvar Version "6.5.0 patch"

/*
Detect SQLCMD mode and disable script execution if SQLCMD mode is not supported.
To re-enable the script after enabling SQLCMD mode, execute the following:
SET NOEXEC OFF; 
*/
:setvar __IsSqlCmdEnabled "True"
GO
IF N'$(__IsSqlCmdEnabled)' NOT LIKE N'True'
    BEGIN
        PRINT N'SQLCMD mode must be enabled to successfully execute this script.';
        SET NOEXEC ON;
    END
GO

USE [master];
GO
IF  EXISTS (SELECT * FROM master.sys.server_triggers WHERE parent_class_desc = 'SERVER' AND name = N'$(DatabaseName)_protect')
	DROP TRIGGER [$(DatabaseName)_protect] ON ALL SERVER
GO

USE [_dbaid];
GO

IF DB_NAME() = '_dbaid'
BEGIN
  IF EXISTS (SELECT * FROM sys.triggers WHERE parent_class = 0 AND name = 'trg_stop_ddl_modification')
	  DROP TRIGGER [trg_stop_ddl_modification] ON DATABASE;
END
GO

IF EXISTS (SELECT * FROM sys.triggers WHERE parent_class = 1 AND name = 'trg_stop_staticparameter_change')
    DROP TRIGGER [dbo].[trg_stop_staticparameter_change]
GO

IF EXISTS (SELECT * FROM sys.triggers WHERE parent_class = 1 AND name = 'trg_stop_version_change')
    DROP TRIGGER [dbo].[trg_stop_version_change]
GO

IF NOT EXISTS (SELECT 1 FROM [_dbaid].[dbo].[static_parameters] WHERE [name] = N'TENANT_NAME')
  INSERT INTO [_dbaid].[dbo].[static_parameters] ([name], [value], [description]) VALUES (N'TENANT_NAME', N'$(Tenant)', N'Name of site/customer being monitored.');
GO
IF NOT EXISTS (SELECT 1 FROM [_dbaid].[dbo].[version] WHERE [version] = N'$(Version)')
  INSERT INTO [_dbaid].[dbo].[version]([version]) VALUES('$(Version)');
GO


IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'get_instance_version' AND [schema_id] = SCHEMA_ID(N'dbo'))
  EXEC sp_executesql N'CREATE FUNCTION [dbo].[get_instance_version] (@dummy bit) RETURNS @output TABLE (string nvarchar(4000)) AS BEGIN RETURN; END';
GO 

ALTER FUNCTION [dbo].[get_instance_version] (@dummy bit)
RETURNS 
@output TABLE
(
	string nvarchar(4000)
)
WITH ENCRYPTION
AS
BEGIN
    DECLARE @edition nvarchar(4000),
            @patch_level sysname;
    SELECT @edition = CAST([value] AS sysname) 
           + N',' 
           + CAST(SERVERPROPERTY('MachineName') AS sysname) 
           + N'#' 
           + ISNULL(CAST(SERVERPROPERTY('InstanceName') AS sysname), N'MSSQLSERVER') 
           + N',Microsoft SQL Server '
           + CASE LEFT(CAST(SERVERPROPERTY('ProductVersion') AS sysname), 4)
               WHEN N'16.0' THEN N'2022 '
               WHEN N'15.0' THEN N'2019 '
               WHEN N'14.0' THEN N'2017 '
               WHEN N'13.0' THEN N'2016 '
               WHEN N'12.0' THEN N'2014 '
               WHEN N'11.0' THEN N'2012 '
               WHEN N'10.5' THEN N'2008 R2 '
               WHEN N'10.0' THEN N'2008 '
               WHEN N'9.0.' THEN N'2005 '
               WHEN N'8.00' THEN N'2000 '
               ELSE N'xxxx '
             END
           + RTRIM(REPLACE(REPLACE(REPLACE(CAST(SERVERPROPERTY('Edition') AS sysname), N': Core-based Licensing', N''), N'Edition', N''), N'  ', N' '))
           ,@patch_level = CAST(SERVERPROPERTY('ProductLevel') AS sysname) 
           + ISNULL(N'-' + CAST(SERVERPROPERTY('ProductUpdateLevel') AS sysname), N'') 
           + ISNULL(N'-' + CAST(SERVERPROPERTY('ProductBuildType') AS sysname), N'') + N',' 
           + CAST(SERVERPROPERTY('ProductVersion') AS sysname)
    FROM [dbo].[static_parameters] WHERE [name] = N'TENANT_NAME';

	INSERT INTO @output
        SELECT N'0 mssql_' 
               + ISNULL(CAST(SERVERPROPERTY('InstanceName') AS sysname), N'MSSQLSERVER') 
               + N' - ' 
               + CASE RIGHT(@edition, 8)
                   WHEN N'(64-bit)' THEN REPLACE(@edition, N' (64-bit)', N'')
                   ELSE @edition + N' 32-bit'
                 END
               + N',' 
               + @patch_level;	
    RETURN
END
GO

GRANT SELECT ON [dbo].[get_instance_version] TO [monitor]
GO
GRANT SELECT ON [dbo].[get_instance_version] TO [admin]
GO



IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'backup' AND [schema_id] = SCHEMA_ID(N'check'))
  EXEC sp_executesql N'CREATE PROCEDURE [check].[backup] WITH ENCRYPTION AS SELECT 1;';
GO

/*
Copyright (C) 2015 Datacom
GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007
*/

ALTER PROCEDURE [check].[backup]
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @check TABLE([message] NVARCHAR(4000)
						,[state] NVARCHAR(8));

	DECLARE @to_backup INT;
	DECLARE @not_backup INT;
	DECLARE @tenant NVARCHAR(256);
  
	SELECT @tenant = CAST([value] AS nvarchar(256)) FROM [_dbaid].[dbo].[static_parameters] WHERE [name] = N'TENANT_NAME';

	EXECUTE AS LOGIN = N'_dbaid_sa';

	IF SERVERPROPERTY('IsHadrEnabled') = 1
	BEGIN
		EXEC [dbo].[sp_executesql] @stmt = N'
		DECLARE @check TABLE([message] NVARCHAR(4000)
					,[state] NVARCHAR(8));

		DECLARE @to_backup INT;
		DECLARE @not_backup INT;

		DECLARE @tenant NVARCHAR(256);

		SELECT @tenant = CAST([value] AS nvarchar(256)) FROM [_dbaid].[dbo].[static_parameters] WHERE [name] = N''TENANT_NAME'';

		DECLARE @ag_table AS TABLE (
			[ag_id] UNIQUEIDENTIFIER,
			[name] SYSNAME, 
			[database_id] INT, 
			[automated_backup_preference] TINYINT,
			[role] TINYINT
		);

		INSERT into @ag_table
		SELECT [AG].[group_id],
			[AG].[name], 
			[DS].[database_id], 
			[AG].[automated_backup_preference],
			[RS].[role] 
		FROM [master].[sys].[dm_hadr_availability_replica_states] [RS]
			INNER JOIN [master].[sys].[dm_hadr_database_replica_states] [DS]
				ON [RS].[group_id] = [DS].[group_id]
				AND [RS].[is_local] = 1  
				AND [DS].[is_local] = 1
			INNER JOIN [master].[sys].[availability_groups] [AG]
				ON [AG].[group_id] = [RS].[group_id]

		SELECT @to_backup=COUNT(*) FROM [dbo].[config_database] [D]
		LEFT JOIN (SELECT [AG].[name], 
						[DS].[database_id], 
						[AG].[automated_backup_preference],
						[RS].[role] 
					FROM  [master].[sys].[dm_hadr_availability_replica_states] [RS]
						INNER JOIN [master].[sys].[dm_hadr_database_replica_states] [DS]
							ON [RS].[group_id] = [DS].[group_id]
								AND [RS].[is_local] = 1  AND [DS].[is_local] = 1
						INNER JOIN [master].[sys].[availability_groups] [AG]
							ON [AG].[group_id] = [RS].[group_id]) AS [table] 
								ON [table].[database_id] = [D].[database_id]
		WHERE [backup_frequency_hours] > 0 
			AND LOWER([db_name]) NOT IN (N''tempdb'')
			AND [is_enabled] = 1
			AND ISNULL([table].[automated_backup_preference],0) = 0
			AND ISNULL([table].[role],1) = 1

		SELECT @not_backup=COUNT(*) - @to_backup FROM [dbo].[config_database] [D] WHERE LOWER([db_name]) NOT IN (N''tempdb'') OR [is_enabled] = 0	

		;WITH Backups
		AS
		(
			SELECT ROW_NUMBER() OVER (PARTITION BY [D].[name] ORDER BY [B].[backup_finish_date] DESC) AS [row]
				,[D].[database_id]
				,[B].[backup_finish_date]
				,[B].[type]
				,[D].[create_date]
			FROM [sys].[databases] [D]
				LEFT JOIN [msdb].[dbo].[backupset] [B]
					ON [D].[name] = [B].[database_name]
						AND [B].[type] IN (''D'', ''I'')
						AND [B].[is_copy_only] = 0
			WHERE [D].[state] = 0
				AND [D].[is_in_standby] = 0
		)
		INSERT INTO @check
		SELECT @tenant
			+ N'','' + CAST(SERVERPROPERTY(''MachineName'') AS sysname)
			+ N''#'' + ISNULL(CAST(SERVERPROPERTY(''InstanceName'') AS sysname), N''MSSQLSERVER'')
			+ N''#'' + [D].[db_name]
			+ N'','' + ISNULL(CONVERT(NVARCHAR(20), [B].[backup_finish_date], 23), N''1900-01-01'')
			+ N'','' + CASE [type] WHEN ''D'' THEN ''FULL'' WHEN ''I'' THEN ''DIFFERENTIAL'' ELSE ''UNKNOWN'' END
			,[S].[state]
		FROM Backups [B]
			INNER JOIN [_dbaid].[dbo].[config_database] [D]
				ON [B].[database_id] = [D].[database_id]
			LEFT JOIN @ag_table AS [AGT]
				ON [AGT].[database_id] = [D].[database_id] 
			LEFT JOIN [_dbaid].[dbo].[config_alwayson] [ca]
				ON [AGT].[ag_id] = [ca].[ag_id]
			CROSS APPLY (SELECT CASE WHEN ([B].[backup_finish_date] IS NULL OR DATEDIFF(HOUR, [B].[backup_finish_date], GETDATE()) > ([D].[backup_frequency_hours])) THEN [D].[backup_state_alert] ELSE N''OK'' END AS [state]) [S]
		WHERE [B].[row] = 1
			AND [D].[backup_frequency_hours] > 0
			/* AND DATEDIFF(HOUR, [B].[create_date], GETDATE()) > [D].[backup_frequency_hours] */
			AND LOWER([D].[db_name]) NOT IN (N''tempdb'')
			AND ISNULL([AGT].[automated_backup_preference],0) = 0
			AND ISNULL([AGT].[role],1) = 1
			AND ((DATEDIFF(HOUR, [ca].[ag_role_change_datetime], GETDATE()) > [D].[backup_frequency_hours]) OR ([ca].[ag_role_change_datetime] IS NULL))
			/* AND [S].[state] NOT IN (N''OK'') */
			AND [D].[is_enabled] = 1
		ORDER BY [D].[db_name]

		IF (SELECT COUNT(*) FROM @check) < 1
			INSERT INTO @check VALUES(CAST(@to_backup AS NVARCHAR(10)) + N'' database(s) monitored, '' + CAST(@not_backup AS NVARCHAR(10)) + N'' database(s) opted-out'', N''NA'');

		SELECT [message], [state] 
		FROM @check;'
	END
	ELSE
	BEGIN
		SELECT @to_backup=COUNT(*) FROM [_dbaid].[dbo].[config_database] WHERE [backup_frequency_hours] > 0 AND LOWER([db_name]) NOT IN (N'tempdb') AND [is_enabled] = 1
		SELECT @not_backup=COUNT(*) FROM [_dbaid].[dbo].[config_database] WHERE [backup_frequency_hours] = 0 AND LOWER([db_name]) NOT IN (N'tempdb') OR [is_enabled] = 0

		;WITH Backups
		AS
		(
			SELECT ROW_NUMBER() OVER (PARTITION BY [D].[name] ORDER BY [B].[backup_finish_date] DESC) AS [row]
				,[D].[database_id]
				,[B].[backup_finish_date]
				,[B].[type]
				,[D].[create_date]
			FROM [sys].[databases] [D]
				LEFT JOIN [msdb].[dbo].[backupset] [B]
					ON [D].[name] = [B].[database_name]
						AND [B].[type] IN ('D', 'I')
						AND [B].[is_copy_only] = 0
			WHERE [D].[state] = 0
				AND [D].[is_in_standby] = 0
		)
		/* Using # as separator for ServerName\InstanceName\DatabaseName as an instance or database with [lower case?] "n" as first character
			 leads to a "\n" combination that Checkmk interprets as a newline character. Does not seem to be possible to escape this combination
			 to stop it happening.
		*/
		INSERT INTO @check
		SELECT @tenant
				+ N',' + CAST(SERVERPROPERTY('MachineName') AS sysname) 
				+ N'#' + ISNULL(CAST(SERVERPROPERTY('InstanceName') AS sysname), N'MSSQLSERVER')
				+ N'#' + [D].[db_name]
				+ N',' + ISNULL(CONVERT(NVARCHAR(20), [B].[backup_finish_date], 23), N'1900-01-01')
				+ N',' + CASE [type] WHEN 'D' THEN 'FULL' WHEN 'I' THEN 'DIFFERENTIAL' ELSE 'UNKNOWN' END
				,[S].[state]
		FROM Backups [B]
			INNER JOIN [_dbaid].[dbo].[config_database] [D]
				ON [B].[database_id] = [D].[database_id]
			CROSS APPLY (SELECT CASE WHEN ([B].[backup_finish_date] IS NULL OR DATEDIFF(HOUR, [B].[backup_finish_date], GETDATE()) > ([D].[backup_frequency_hours])) THEN [D].[backup_state_alert] ELSE N'OK' END AS [state]) [S]
		WHERE [B].[row] = 1
			AND [D].[backup_frequency_hours] > 0
			--AND DATEDIFF(HOUR, [B].[create_date], GETDATE()) > [D].[backup_frequency_hours]
			AND LOWER([D].[db_name]) NOT IN (N'tempdb')
			--AND [S].[state] NOT IN (N'OK')
			AND [D].[is_enabled] = 1
		ORDER BY [D].[db_name]

		IF (SELECT COUNT(*) FROM @check) < 1
			INSERT INTO @check VALUES(CAST(@to_backup AS NVARCHAR(10)) + N' database(s) monitored, ' + CAST(@not_backup AS NVARCHAR(10)) + N' database(s) opted-out', N'NA');

		SELECT [message],[state] 
		FROM @check;
	END

	REVERT;
END
GO



IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'inventory' AND [schema_id] = SCHEMA_ID(N'check'))
  EXEC sp_executesql N'CREATE PROCEDURE [check].[inventory] WITH ENCRYPTION AS SELECT 1;';
GO


/*
Copyright (C) 2015 Datacom
GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007
*/

ALTER PROCEDURE [check].[inventory]
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;
	
	EXECUTE AS LOGIN = N'$(DatabaseName)_sa';

	DECLARE @check TABLE([message] NVARCHAR(4000)
						,[state] NVARCHAR(8));

    /* Using # as separator for ServerName\InstanceName\DatabaseName as an instance or database with [lower case?] "n" as first character
         leads to a "\n" combination that Checkmk interprets as a newline character. Does not seem to be possible to escape this combination
         to stop it happening.
    */
    INSERT INTO @check
    SELECT CAST(s.[value] AS sysname) 
            + N',' 
            + CAST(SERVERPROPERTY('MachineName') AS sysname) 
            + N'#' 
            + ISNULL(CAST(SERVERPROPERTY('InstanceName') AS sysname), N'MSSQLSERVER') 
            + N'#' + D.[name]
            , N'OK'
    FROM [$(DatabaseName)].[dbo].[static_parameters] s, sys.databases D 
      INNER JOIN [$(DatabaseName)].[dbo].[config_database] c ON D.[database_id] = c.[database_id]
    WHERE s.[name] = N'TENANT_NAME'
      /* exclude system databases & _dbaid as none of these are loaded into CMDB */
      AND D.[name] NOT IN (N'_dbaid', N'master', N'model', N'msdb', N'tempdb')
      AND ((D.[state_desc] NOT IN (N'OFFLINE')) OR (D.[state_desc] IN (N'OFFLINE') AND c.[is_enabled] = 1));

    IF (SELECT COUNT(*) FROM @check) = 0
        INSERT INTO @check ([message], [state]) VALUES (N'No user databases found.', N'NA');

    SELECT [message], [state] FROM @check;

	REVERT;
END
GO


IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE [name] = N'job' AND [schema_id] = SCHEMA_ID(N'check'))
  EXEC sp_executesql N'CREATE PROCEDURE [check].[job] WITH ENCRYPTION AS SELECT 1;';
GO
/*
Copyright (C) 2015 Datacom
GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007
*/

ALTER PROCEDURE [check].[job]
WITH ENCRYPTION
AS
BEGIN
	SET NOCOUNT ON;

	EXECUTE AS LOGIN = N'$(DatabaseName)_sa';

	DECLARE @check TABLE([message] NVARCHAR(4000)
						,[state] NVARCHAR(8));

	DECLARE @countjobenabled INT, @countjobdisabled INT;

	SELECT @countjobenabled=COUNT(*)
	FROM [dbo].[config_job]
	WHERE [is_enabled] = 1

	SELECT @countjobdisabled=COUNT(*)
	FROM [dbo].[config_job]
	WHERE [is_enabled] = 0

	;WITH [jobset]
	AS
	(
		SELECT ROW_NUMBER() OVER (PARTITION BY [J].[name] ORDER BY [JS].[last_run_date] DESC, [JS].[last_run_time] DESC) AS [row]
			,[J].[job_id]
			,[J].[name]
			,[JS].[last_run_outcome]
		FROM [msdb].[dbo].[sysjobs] [J]
			INNER JOIN [msdb].[dbo].[sysjobservers] [JS]
				ON [J].[job_id] = [JS].[job_id]
		WHERE [J].[enabled] = 1
	)
	INSERT INTO @check
		SELECT N'job=' + QUOTENAME([J].[name]) COLLATE Database_Default
				+ N'; state=' 
				+ CASE [J].[last_run_outcome] 
					WHEN 0 THEN N'FAIL'
					WHEN 1 THEN N'SUCCESS'
					WHEN 2 THEN N'RETRY'
					WHEN 3 THEN N'CANCEL'
					WHEN 4 THEN N'IN PROGRESS'
					ELSE N'UNKNOWN' END AS [message]
			,CASE WHEN [J].[last_run_outcome] IN (0) THEN [C].[change_state_alert] ELSE 'OK' END AS [state]
		FROM [jobset] [J]
			INNER JOIN [dbo].[config_job] [C]
				ON [J].[job_id] = [C].[job_id]
		WHERE [J].[row] = 1
			AND [C].[is_enabled] = 1
	  AND [J].[last_run_outcome] = 0;

	IF (SELECT COUNT(*) FROM @check) < 1
		INSERT INTO @check 
		VALUES(CAST(@countjobenabled AS NVARCHAR(10)) 
			+ N' job(s) monitored; ' 
			+ CAST(@countjobdisabled AS NVARCHAR(10))
			+ ' job(s) not monitored; '
			,N'NA');

	SELECT [message], [state] FROM @check;

	REVERT;
END
GO


/*
Copyright (C) 2015 Datacom
GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007
*/

ALTER PROCEDURE [deprecated].[Databases]
WITH ENCRYPTION
AS
BEGIN
    SET NOCOUNT ON;

    EXECUTE AS LOGIN = N'$(DatabaseName)_sa';

    DECLARE @client varchar(128);

    SELECT @client = REPLACE(REPLACE(REPLACE(CAST(SERVERPROPERTY('Servername') AS varchar(128)) + [setting], '@', '_'), '.', '_'), '\', '#')
    FROM [$(DatabaseName)].[deprecated].[tbparameters] 
    WHERE [parametername] = 'Client_domain';

    SELECT @client AS [Client]
            ,GETDATE() AS [Checkdate]
            ,db.[name]
            ,CAST(ROUND(SUM(CAST([size] AS bigint))/128.00, 2) AS NUMERIC(20,2)) AS [size]
            ,ISNULL(SUSER_SNAME(db.[owner_sid]), '~~UNKNOWN~~') AS [owner]
            ,db.[database_id] AS [dbid]
            ,db.[create_date] AS [Created]
            ,'Status =' + CONVERT(sysname, db.[state_desc]) 
                + '| Updateability=' + CASE db.[is_read_only] WHEN 0 THEN 'READ_WRITE' ELSE 'READ_ONLY' END 
                + '| Recovery=' + CONVERT(sysname, db.[recovery_model_desc] )
                + '| Collation=' + CONVERT(sysname, ISNULL(db.[collation_name], CONVERT(sysname, SERVERPROPERTY('Collation')))) COLLATE DATABASE_DEFAULT AS [Status]
            ,db.[compatibility_level] AS [Compatailiity_level]
    FROM sys.databases db 
      INNER JOIN sys.master_files mf ON mf.database_id = db.database_id
      INNER JOIN [$(DatabaseName)].[dbo].[config_database] c ON db.database_id = c.database_id
    /* Logic for SACM CMDB reconciliation:
        If database is OFFLINE and monitoring [is_enabled] is False, don't include as it is assumed planned outage/pending decommission. Update CMDB.
        If database is OFFLINE and monitoring [is_enabled] is True, include as it is assumed there's a problem (which is why the database is OFFLINE) or someone hasn't updated monitoring & CMDB for a decommission.
        If database is NOT OFFLINE and monitoring [is_enabled] is False, include as it is assumed planned outage or similar to prevent alerts. It should still appear for CMDB reconciliation. If not, set CI to Non Discoverable in CMDB.
        If database id NOT OFFLINE and monitoring [is_enabled] is True, include it as this is the status quo for normal operation.
    */
    WHERE (db.[state_desc] IN (N'OFFLINE') AND c.[is_enabled] = 1)
       OR (db.[state_desc] NOT IN (N'OFFLINE'))
    GROUP BY db.[name], db.[owner_sid], db.[database_id], db.[create_date], db.[state_desc], db.[is_read_only], db.[recovery_model_desc], db.[collation_name], db.[compatibility_level];
     
    IF (SELECT [value] FROM [$(DatabaseName)].[dbo].[static_parameters] WHERE [name] = 'PROGRAM_NAME') = PROGRAM_NAME()
	    UPDATE [$(DatabaseName)].[dbo].[procedure] 
        SET [last_execution_datetime] = GETDATE() 
        WHERE [procedure_id] = @@PROCID;

    REVERT;
END

GO



/* Update procedure list in db */
INSERT INTO [dbo].[procedure] ([procedure_id],[schema_name],[procedure_name],[description],[is_enabled],[last_execution_datetime])
	SELECT [O].[object_id] AS [procedure_id]
		,OBJECT_SCHEMA_NAME([O].[object_id]) AS [schema_name]
		,OBJECT_NAME([O].[object_id]) AS [procedure_name]
		,CASE OBJECT_SCHEMA_NAME([O].[object_id])
			WHEN 'log' THEN 'Historic log information.'
			WHEN 'report' THEN 'Meta data reports.'
			WHEN 'check' THEN 'Monitoring state checks'
			WHEN 'chart' THEN 'PnP4Nagios performance counters'
			WHEN 'deprecated' THEN 'Legacy DailyChecks procedures.'
			WHEN 'fact' THEN 'configuration fact generator procedures'
			END AS [description]
		,1 AS [is_enabled]
		,NULL
	FROM [sys].[objects] [O]
		LEFT JOIN [dbo].[procedure] [P]
			ON OBJECT_SCHEMA_NAME([O].[object_id]) = [P].[schema_name]
				AND OBJECT_NAME([O].[object_id]) = [P].[procedure_name]
	WHERE [type] = 'P' AND OBJECT_SCHEMA_NAME(object_id) IN ('log','deprecated','report','check','chart','fact') 
		AND [P].[procedure_id] IS NULL
	ORDER BY OBJECT_SCHEMA_NAME(object_id), OBJECT_NAME(object_id);
GO
